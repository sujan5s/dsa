class graph{
    
}